<?php 
    $quantity = $_POST['quantity'];
    $hd = $_POST['hd'];
    $loc = $_POST['loc'];
    $tip = $_POST['tip'];
    
    
    $bill = $quantity * 12.5;

    if($quantity>=1 && $quantity <=9){
        $bill = $bill*0.95;
    }
    elseif($quantity>=10 && $quantity <=19){
        $bill = $bill*0.90;
    }
    else if($quantity>=20){
        $bill = $bill*0.85;
    }
    if($hd == "yes"){
        $bill = $bill + 40.0;
    }
    if($loc == "dhaka"){
        $bill = $bill * 1.20;
    }
    else{
        $bill = $bill * 1.15;
    }
    $bill = $bill + $tip;

    echo "Your total bill is: $bill";


?>