<head>
    <style>
        table,tr,td{
            border:1px solid black;
        }
        table{
            border-collapse:collapse;
        }
    </style>
</head>
<?php 
    $n = $_POST['n'];
    echo "<table>";
    for($i=1;$i<=$n;$i++){
        echo "<tr>";
        for($j=1;$j<=$n;$j++){
            echo "<td>1</td>";
        }
        echo "</tr>";
    }
    echo "</table>";
    


?>